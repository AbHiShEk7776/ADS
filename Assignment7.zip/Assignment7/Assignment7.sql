CREATE DATABASE xmart_dw;
USE xmart_dw;
-- Create Dimension Tables
CREATE TABLE dim_product (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    brand VARCHAR(50),
    price DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dim_customer (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(100) NOT NULL,
    gender ENUM('Male', 'Female', 'Other'),
    age INT,
    region VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dim_store (
    store_id INT PRIMARY KEY AUTO_INCREMENT,
    store_name VARCHAR(100) NOT NULL,
    location VARCHAR(100),
    manager_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dim_date (
    date_id INT PRIMARY KEY AUTO_INCREMENT,
    full_date DATE NOT NULL,
    day INT,
    month INT,
    year INT,
    quarter INT,
    weekday ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
    is_weekend BOOLEAN
);

CREATE TABLE dim_time (
    time_id INT PRIMARY KEY AUTO_INCREMENT,
    time_of_day TIME NOT NULL,
    hour INT,
    period ENUM('Morning', 'Afternoon', 'Evening', 'Night')
);

CREATE TABLE dim_salesperson (
    salesperson_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    position VARCHAR(50),
    hire_date DATE
);
-- Facts Table
CREATE TABLE fact_sales (
    sales_id INT PRIMARY KEY AUTO_INCREMENT,
    date_id INT,
    time_id INT,
    product_id INT,
    customer_id INT,
    store_id INT,
    salesperson_id INT,
    invoice_number VARCHAR(50),
    quantity_sold INT,
    total_sales DECIMAL(12, 2),
    actual_cost DECIMAL(12, 2),
    record_count INT DEFAULT 1,
    FOREIGN KEY (date_id) REFERENCES dim_date(date_id),
    FOREIGN KEY (time_id) REFERENCES dim_time(time_id),
    FOREIGN KEY (product_id) REFERENCES dim_product(product_id),
    FOREIGN KEY (customer_id) REFERENCES dim_customer(customer_id),
    FOREIGN KEY (store_id) REFERENCES dim_store(store_id),
    FOREIGN KEY (salesperson_id) REFERENCES dim_salesperson(salesperson_id)
);
-- Populate the Data
DELIMITER $$

CREATE PROCEDURE PopulateProducts2000()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 2000 DO
        INSERT INTO dim_product (product_name, category, brand, price) 
        VALUES (
            CONCAT('Product_', i),
            IF(MOD(i, 3) = 0, 'Electronics', IF(MOD(i, 3) = 1, 'Fashion', 'Home')),
            IF(MOD(i, 2) = 0, 'BrandA', 'BrandB'),
            ROUND(RAND() * 10000 + 500, 2)
        );
        SET i = i + 1;
    END WHILE;
END$$

DELIMITER ;

CALL PopulateProducts2000();

DELIMITER $$

CREATE PROCEDURE PopulateCustomers2000()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 2000 DO
        INSERT INTO dim_customer (customer_name, gender, age, region) 
        VALUES (
            CONCAT('Customer_', i),
            IF(MOD(i, 2) = 0, 'Male', 'Female'),
            FLOOR(RAND() * 50 + 18),
            IF(MOD(i, 4) = 0, 'Mumbai', IF(MOD(i, 4) = 1, 'Pune', IF(MOD(i, 4) = 2, 'Delhi', 'Bangalore')))
        );
        SET i = i + 1;
    END WHILE;
END$$

DELIMITER ;

CALL PopulateCustomers2000();

DELIMITER $$

CREATE PROCEDURE PopulateStores50()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 50 DO
        INSERT INTO dim_store (store_name, location, manager_name) 
        VALUES (
            CONCAT('Store_', i),
            IF(MOD(i, 2) = 0, 'Mumbai', 'Pune'),
            CONCAT('Manager_', i)
        );
        SET i = i + 1;
    END WHILE;
END$$

DELIMITER ;

CALL PopulateStores50();

DELIMITER $$

CREATE PROCEDURE PopulateDates365()
BEGIN
    DECLARE i INT DEFAULT 0;
    WHILE i < 365 DO
        INSERT INTO dim_date (full_date, day, month, year, quarter, weekday, is_weekend) 
        VALUES (
            DATE_ADD('2024-01-01', INTERVAL i DAY),
            DAY(DATE_ADD('2024-01-01', INTERVAL i DAY)),
            MONTH(DATE_ADD('2024-01-01', INTERVAL i DAY)),
            YEAR(DATE_ADD('2024-01-01', INTERVAL i DAY)),
            QUARTER(DATE_ADD('2024-01-01', INTERVAL i DAY)),
            DAYNAME(DATE_ADD('2024-01-01', INTERVAL i DAY)),
            IF(DAYOFWEEK(DATE_ADD('2024-01-01', INTERVAL i DAY)) IN (1, 7), TRUE, FALSE)
        );
        SET i = i + 1;
    END WHILE;
END$$

DELIMITER ;

CALL PopulateDates365();

DELIMITER $$

CREATE PROCEDURE PopulateTimes24()
BEGIN
    DECLARE i INT DEFAULT 0;
    WHILE i < 24 DO
        INSERT INTO dim_time (time_of_day, hour, period) 
        VALUES (
            TIME_FORMAT(CONCAT(i, ':00:00'), '%H:%i:%s'),
            i,
            CASE
                WHEN i < 12 THEN 'Morning'
                WHEN i < 18 THEN 'Afternoon'
                ELSE 'Evening'
            END
        );
        SET i = i + 1;
    END WHILE;
END$$

DELIMITER ;

CALL PopulateTimes24();

DELIMITER $$

CREATE PROCEDURE PopulateSalespersons200()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 200 DO
        INSERT INTO dim_salesperson (name, position, hire_date) 
        VALUES (
            CONCAT('Salesperson_', i),
            IF(MOD(i, 2) = 0, 'Senior Executive', 'Junior Executive'),
            DATE_SUB(CURRENT_DATE, INTERVAL FLOOR(RAND() * 365 * 5) DAY)
        );
        SET i = i + 1;
    END WHILE;
END$$

DELIMITER ;

CALL PopulateSalespersons200();

DELIMITER $$

CREATE PROCEDURE PopulateSales2000()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 2000 DO
        INSERT INTO fact_sales (date_id, time_id, product_id, customer_id, store_id, salesperson_id, invoice_number, quantity_sold, total_sales, actual_cost) 
        VALUES (
            FLOOR(RAND() * 365) + 1,                        -- Random Date (1-365)
            FLOOR(RAND() * 24) + 1,                         -- Random Time (1-24)
            FLOOR(RAND() * 2000) + 1,                       -- Random Product (1-2000)
            FLOOR(RAND() * 2000) + 1,                       -- Random Customer (1-2000)
            FLOOR(RAND() * 50) + 1,                         -- Random Store (1-50)
            FLOOR(RAND() * 200) + 1,                        -- Random Salesperson (1-200)
            CONCAT('INV-', LPAD(i, 7, '0')),                -- Invoice Number
            FLOOR(RAND() * 10) + 1,                         -- Quantity (1-10)
            ROUND(RAND() * 10000 + 500, 2),                 -- Total Sales
            ROUND(RAND() * 8000 + 400, 2)                   -- Actual Cost
        );
        SET i = i + 1;
    END WHILE;
END$$

DELIMITER ;

CALL PopulateSales2000();

-- Query 1
SELECT s.store_name, d.month, SUM(f.total_sales) AS total_revenue
FROM fact_sales f
JOIN dim_store s ON f.store_id = s.store_id
JOIN dim_date d ON f.date_id = d.date_id
GROUP BY s.store_name, d.month WITH ROLLUP;

-- Query 2
SELECT c.region, p.product_name, SUM(f.total_sales) AS revenue
FROM fact_sales f
JOIN dim_customer c ON f.customer_id = c.customer_id
JOIN dim_product p ON f.product_id = p.product_id
GROUP BY c.region, p.product_name
ORDER BY revenue DESC
LIMIT 10;

-- Query 3
SELECT t.period, SUM(f.total_sales) AS total_sales
FROM fact_sales f
JOIN dim_time t ON f.time_id = t.time_id
GROUP BY t.period;
 
 -- Query 4
 SELECT d.year, SUM(f.total_sales) AS yearly_sales
FROM fact_sales f
JOIN dim_date d ON f.date_id = d.date_id
GROUP BY d.year
ORDER BY d.year;

-- Query 5
SELECT d.weekday, SUM(f.total_sales) AS revenue
FROM fact_sales f
JOIN dim_date d ON f.date_id = d.date_id
GROUP BY d.weekday
ORDER BY FIELD(d.weekday, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
-- Query 6
SELECT sp.name AS salesperson_name, SUM(f.total_sales) AS total_revenue
FROM fact_sales f
JOIN dim_salesperson sp ON f.salesperson_id = sp.salesperson_id
GROUP BY sp.name
ORDER BY total_revenue DESC
LIMIT 10;

-- Query 7
SELECT p.category, p.brand, SUM(f.total_sales) AS total_sales
FROM fact_sales f
JOIN dim_product p ON f.product_id = p.product_id
GROUP BY p.category, p.brand WITH ROLLUP;
-- Query 8
SELECT d.year, SUM(f.total_sales) AS yearly_sales
FROM fact_sales f
JOIN dim_date d ON f.date_id = d.date_id
WHERE d.year BETWEEN YEAR(CURRENT_DATE) - 1 AND YEAR(CURRENT_DATE)
GROUP BY d.year
ORDER BY d.year;

-- Query 9
SELECT p.product_name, d.is_weekend, SUM(f.quantity_sold) AS total_sold
FROM fact_sales f
JOIN dim_product p ON f.product_id = p.product_id
JOIN dim_date d ON f.date_id = d.date_id
GROUP BY p.product_name, d.is_weekend
ORDER BY total_sold DESC
LIMIT 10;

-- Query 10
SELECT s.store_name, d.month, SUM(f.total_sales) AS total_sales
FROM fact_sales f
JOIN dim_store s ON f.store_id = s.store_id
JOIN dim_date d ON f.date_id = d.date_id
GROUP BY s.store_name, d.month
ORDER BY s.store_name, d.month;



