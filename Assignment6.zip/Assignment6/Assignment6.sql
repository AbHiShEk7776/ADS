CREATE DATABASE IF NOT EXISTS DataWarehouse;
USE DataWarehouse;
-- Dimension Tables 
CREATE TABLE DimCity (
    City_id INT PRIMARY KEY,
    City_name VARCHAR(100),
    State VARCHAR(100),
    Headquarter_addr VARCHAR(255)
);

CREATE TABLE DimCustomer (
    Customer_id INT PRIMARY KEY,
    Customer_name VARCHAR(100),
    City_id INT,
    First_order_date DATE,
    Customer_Type ENUM('Walk-in', 'Mail-order', 'Dual'),
    FOREIGN KEY (City_id) REFERENCES DimCity(City_id)
);

CREATE TABLE DimStore (
    Store_id INT PRIMARY KEY,
    City_id INT,
    Phone VARCHAR(20),
    FOREIGN KEY (City_id) REFERENCES DimCity(City_id)
);

CREATE TABLE DimItem (
    Item_id INT PRIMARY KEY,
    Description VARCHAR(255),
    Size VARCHAR(50),
    Weight DECIMAL(10,2),
    Unit_price DECIMAL(10,2)
);

CREATE TABLE DimDate (
    Date_id INT PRIMARY KEY AUTO_INCREMENT,
    Date DATE UNIQUE,
    Day INT,
    Month INT,
    Year INT,
    Quarter INT
);
-- Fact Tables
CREATE TABLE FactOrder (
    Order_no INT,
    Customer_id INT,
    Store_id INT,
    Item_id INT,
    Date_id INT,
    Quantity_ordered INT,
    Ordered_price DECIMAL(10,2),
    PRIMARY KEY (Order_no, Item_id),
    FOREIGN KEY (Customer_id) REFERENCES DimCustomer(Customer_id),
    FOREIGN KEY (Store_id) REFERENCES DimStore(Store_id),
    FOREIGN KEY (Item_id) REFERENCES DimItem(Item_id),
    FOREIGN KEY (Date_id) REFERENCES DimDate(Date_id)
);

CREATE TABLE FactInventory (
    Store_id INT,
    Item_id INT,
    Date_id INT,
    Quantity_held INT,
    PRIMARY KEY (Store_id, Item_id, Date_id),
    FOREIGN KEY (Store_id) REFERENCES DimStore(Store_id),
    FOREIGN KEY (Item_id) REFERENCES DimItem(Item_id),
    FOREIGN KEY (Date_id) REFERENCES DimDate(Date_id)
);
-- Data Cube Implementation
DELIMITER //

-- Insert Customers (Fix: Ensuring valid City IDs)
CREATE PROCEDURE InsertCustomers(IN num_rows INT)
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= num_rows DO
        INSERT IGNORE INTO DimCustomer (Customer_id, Customer_name, City_id, First_order_date, Customer_Type)
        VALUES (i, 
                CONCAT('Customer_', i), 
                101 + MOD(i, 3),  -- Ensures City_id is 101, 102, or 103
                DATE_ADD('2024-01-01', INTERVAL i DAY), 
                ELT(FLOOR(1 + RAND() * 3), 'Walk-in', 'Mail-order', 'Dual'));
        SET i = i + 1;
    END WHILE;
END //

-- Insert Stores (Fix: Ensuring City IDs match)
CREATE PROCEDURE InsertStores(IN num_rows INT)
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= num_rows DO
        INSERT IGNORE INTO DimStore (Store_id, City_id, Phone)
        VALUES (i, 
                101 + MOD(i, 3),  -- Ensures City_id exists
                CONCAT('555-', LPAD(FLOOR(RAND() * 10000), 4, '0')));
        SET i = i + 1;
    END WHILE;
END //

-- Insert Items
CREATE PROCEDURE InsertItems(IN num_rows INT)
BEGIN
    DECLARE i INT DEFAULT 1001;
    WHILE i < 1001 + num_rows DO
        INSERT IGNORE INTO DimItem (Item_id, Description, Size, Weight, Unit_price)
        VALUES (i, 
                CONCAT('Item_', i), 
                ELT(FLOOR(1 + RAND() * 3), 'S', 'M', 'L'), 
                ROUND(RAND() * 5, 2), 
                ROUND(10 + RAND() * 90, 2));
        SET i = i + 1;
    END WHILE;
END //

-- Insert Cities
CREATE PROCEDURE InsertCities()
BEGIN
    INSERT IGNORE INTO DimCity VALUES 
    (101, 'New York', 'NY', '123 5th Ave, New York, NY'),
    (102, 'Los Angeles', 'CA', '456 Hollywood Blvd, Los Angeles, CA'),
    (103, 'Chicago', 'IL', '789 Michigan Ave, Chicago, IL');
END //

-- Insert Dates
CREATE PROCEDURE InsertDates(IN start_date DATE, IN num_days INT)
BEGIN
    DECLARE i INT DEFAULT 0;
    WHILE i < num_days DO
        INSERT IGNORE INTO DimDate (Date, Day, Month, Year, Quarter)
        VALUES (DATE_ADD(start_date, INTERVAL i DAY), 
                DAY(DATE_ADD(start_date, INTERVAL i DAY)), 
                MONTH(DATE_ADD(start_date, INTERVAL i DAY)), 
                YEAR(DATE_ADD(start_date, INTERVAL i DAY)), 
                QUARTER(DATE_ADD(start_date, INTERVAL i DAY)));
        SET i = i + 1;
    END WHILE;
END //

-- Insert Orders
CREATE PROCEDURE InsertOrders(IN num_orders INT)
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= num_orders DO
        INSERT IGNORE INTO FactOrder (Order_no, Customer_id, Store_id, Item_id, Date_id, Quantity_ordered, Ordered_price)
        VALUES (i, 
                1 + MOD(i, 100),  -- Ensures valid Customer_id
                1 + MOD(i, 50),  -- Ensures valid Store_id
                1001 + MOD(i, 100),  -- Ensures valid Item_id
                1 + MOD(i, 365),  -- Ensures valid Date_id
                FLOOR(1 + RAND() * 5), 
                ROUND(10 + RAND() * 90, 2));
        SET i = i + 1;
    END WHILE;
END //

-- Insert Inventory
CREATE PROCEDURE InsertInventory(IN num_entries INT)
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= num_entries DO
        INSERT IGNORE INTO FactInventory (Store_id, Item_id, Date_id, Quantity_held)
        VALUES (1 + MOD(i, 50),  -- Ensures valid Store_id
                1001 + MOD(i, 100),  -- Ensures valid Item_id
                1 + MOD(i, 365),  -- Ensures valid Date_id
                FLOOR(5 + RAND() * 50));  
        SET i = i + 1;
    END WHILE;
END //

DELIMITER ;

-- Step 5: Execute Data Insertion
CALL InsertCities();
CALL InsertCustomers(100);
CALL InsertStores(50);
CALL InsertItems(100);
CALL InsertDates('2024-01-01', 365);
CALL InsertOrders(1000);
CALL InsertInventory(2000);
-- Query 1
SELECT s.Store_id, c.City_name, c.State, s.Phone, i.Description, i.Size, i.Weight, i.Unit_price, fi.Quantity_held
FROM FactInventory fi
JOIN DimStore s ON fi.Store_id = s.Store_id
JOIN DimCity c ON s.City_id = c.City_id
JOIN DimItem i ON fi.Item_id = i.Item_id
WHERE fi.Item_id = 1001;
-- Query 2
SELECT o.Order_no, cust.Customer_name, d.Date AS Order_Date
FROM FactOrder o
JOIN DimCustomer cust ON o.Customer_id = cust.Customer_id
JOIN DimDate d ON o.Date_id = d.Date_id
WHERE o.Store_id = 1;
-- Query 3
SELECT DISTINCT s.Store_id, c.City_name, s.Phone
FROM FactOrder o
JOIN DimStore s ON o.Store_id = s.Store_id
JOIN DimCity c ON s.City_id = c.City_id
WHERE o.Customer_id = 123;
-- Query 4
SELECT DISTINCT c.Headquarter_addr, c.City_name, c.State
FROM FactInventory fi
JOIN DimStore s ON fi.Store_id = s.Store_id
JOIN DimCity c ON s.City_id = c.City_id
WHERE fi.Quantity_held > 500;
-- Query 5
SELECT o.Order_no, i.Description, s.Store_id, c.City_name
FROM FactOrder o
JOIN DimItem i ON o.Item_id = i.Item_id
JOIN DimStore s ON o.Store_id = s.Store_id
JOIN DimCity c ON s.City_id = c.City_id;
-- Query 6
SELECT c.City_name, c.State
FROM DimCustomer cust
JOIN DimCity c ON cust.City_id = c.City_id
WHERE cust.Customer_id = 456;
-- Query 7
SELECT s.Store_id, fi.Quantity_held
FROM FactInventory fi
JOIN DimStore s ON fi.Store_id = s.Store_id
JOIN DimCity c ON s.City_id = c.City_id
WHERE fi.Item_id = 1001 AND c.City_name = 'New York';
-- Query 8
SELECT o.Order_no, i.Description, o.Quantity_ordered, cust.Customer_name, s.Store_id, c.City_name
FROM FactOrder o
JOIN DimItem i ON o.Item_id = i.Item_id
JOIN DimCustomer cust ON o.Customer_id = cust.Customer_id
JOIN DimStore s ON o.Store_id = s.Store_id
JOIN DimCity c ON s.City_id = c.City_id;
-- Query 9
SELECT Customer_id, Customer_name
FROM DimCustomer
WHERE Customer_Type = 'Dual';
-- Query 10
SELECT i.Item_id, i.Description, SUM(o.Quantity_ordered) AS Total_Sold
FROM FactOrder o
JOIN DimItem i ON o.Item_id = i.Item_id
GROUP BY i.Item_id, i.Description
ORDER BY Total_Sold DESC;
-- Total Orders by City and STore
SELECT c.City_name, s.Store_id, COUNT(o.Order_no) AS Total_Orders
FROM FactOrder o
JOIN DimStore s ON o.Store_id = s.Store_id
JOIN DimCity c ON s.City_id = c.City_id
GROUP BY c.City_name, s.Store_id
ORDER BY Total_Orders DESC;
-- Top Selling Items
SELECT i.Description, SUM(o.Quantity_ordered) AS Total_Sold
FROM FactOrder o
JOIN DimItem i ON o.Item_id = i.Item_id
GROUP BY i.Description
ORDER BY Total_Sold DESC
LIMIT 10;
-- Customer Type Distribution
SELECT Customer_Type, COUNT(*) AS Total_Customers
FROM DimCustomer
GROUP BY Customer_Type;