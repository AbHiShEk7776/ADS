const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const router=express.Router();

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: '22510020',
    password: 'Ashura123@',
    database: 'university'
});

db.connect((err) => {
    if (err) {
        console.error('Database connection error:', err);
        return;
    }
    console.log('✅ MySQL connected');
});

// JWT Secret Key
const SECRET_KEY = "JWTKEY123";

// Middleware to Authenticate Token
const authenticateToken = (req, res, next) => {
    const authHeader = req.header('Authorization');
    if (!authHeader) return res.status(401).json({ message: 'Access Denied. No Token Provided.' });

    const token = authHeader.split(" ")[1]; // Extract token after "Bearer"
    if (!token) return res.status(403).json({ message: 'Invalid Token Format' });

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.status(403).json({ message: 'Invalid or Expired Token' });

        req.user = user; // Attach user data to request
        next();
    });
};
function authorizeRole(allowedRoles) {
    return (req, res, next) => {
        if (!req.user || !allowedRoles.includes(req.user.role)) {
            return res.status(403).json({ message: "Forbidden: Access Denied" });
        }
        next();
    };
}


// API to get all students (Protected Route)
app.get('/api/students', authenticateToken, (req, res) => {
    const sql = 'SELECT * FROM student';
    db.query(sql, (err, result) => {
        if (err) return res.status(500).json({ error: 'Database Query Error' });
        res.json(result);
    });
});

// API to add a new student (Protected Route)
app.post('/api/students', authenticateToken, (req, res) => {
    const { ID, name, dept_name, tot_cred } = req.body;
    const sql = 'INSERT INTO student (ID, name, dept_name, tot_cred) VALUES (?, ?, ?, ?)';

    db.query(sql, [ID, name, dept_name, tot_cred], (err, result) => {
        if (err) return res.status(500).json({ error: 'Failed to add student' });
        res.json({ message: 'Student added successfully' });
    });
});

// Register User (Admin Only)
app.post('/register', authenticateToken, (req, res) => {
    if (req.user.role !== 'Admin') return res.status(403).json({ message: 'Access Forbidden: Admins Only' });

    const { username, password, role, linked_id } = req.body;
    const hashedPassword = bcrypt.hashSync(password, 10);

    let sql, params;

    if (role === 'Student') {
        sql = "INSERT INTO users (username, password_hash, role, student_id) VALUES (?, ?, ?, ?)";
        params = [username, hashedPassword, role, linked_id];
    } else if (role === 'Instructor') {
        sql = "INSERT INTO users (username, password_hash, role, instructor_id) VALUES (?, ?, ?, ?)";
        params = [username, hashedPassword, role, linked_id];
    } else if (role === 'Admin') {
        sql = "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)";
        params = [username, hashedPassword, role];
    } else {
        return res.status(400).json({ message: 'Invalid role provided' });
    }

    db.query(sql, params, (err, result) => {
        if (err) return res.status(500).json({ error: 'Error Registering User' });
        res.status(201).json({ message: '✅ User Registered Successfully' });
    });
});
// app.post('/register-admin', async (req, res) => {
//     const { username, password } = req.body;
    
//     const hashedPassword = bcrypt.hashSync(password, 10);
    
//     const sql = "INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'Admin')";
//     db.query(sql, [username, hashedPassword], (err, result) => {
//         if (err) return res.status(500).json({ error: err.message });
//         res.status(201).json({ message: 'Admin Registered' });
//     });
// });
app.post('/api/admin/create-user', authenticateToken, (req, res) => {
    if (req.user.role !== 'Admin') {
        return res.status(403).json({ message: 'Access Denied' });
    }

    const { username, password, role, linked_id } = req.body;
    const hashedPassword = bcrypt.hashSync(password, 10);

    const sql = "INSERT INTO users (username, password_hash, role, student_id, instructor_id) VALUES (?, ?, ?, ?, ?)";
    const studentId = role === 'Student' ? linked_id : null;
    const instructorId = role === 'Instructor' ? linked_id : null;

    db.query(sql, [username, hashedPassword, role, studentId, instructorId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json({ message: `${role} User Created Successfully` });
    });
});

// Login User
app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body;

    db.query("SELECT * FROM users WHERE username = ?", [username], (err, results) => {
        if (err) return res.status(500).json({ error: 'Database Error' });
        if (results.length === 0) return res.status(400).json({ message: '❌ User Not Found' });

        const user = results[0];
        const isValidPassword = bcrypt.compareSync(password, user.password_hash);
        if (!isValidPassword) return res.status(400).json({ message: '❌ Invalid Password' });

        const token = jwt.sign({ id: user.user_id, role: user.role }, SECRET_KEY, { expiresIn: '1h' });

        res.json({ token, role: user.role, message: '✅ Login Successful' });
    });
});

// Protected Dashboard Route
app.get('/dashboard', authenticateToken, (req, res) => {
    res.json({ message: `Welcome, ${req.user.role}!` });
});
router.get('/departments', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    db.query('SELECT * FROM department', (err, results) => {
        if (err) return res.status(500).json({ error: 'Error fetching departments' });
        res.json(results);
    });
});

// Get all courses
router.get('/courses', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    db.query('SELECT * FROM course', (err, results) => {
        if (err) return res.status(500).json({ error: 'Error fetching courses' });
        res.json(results);
    });
});

// Get all instructors
router.get('/instructors', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    db.query('SELECT * FROM instructor', (err, results) => {
        if (err) return res.status(500).json({ error: 'Error fetching instructors' });
        res.json(results);
    });
});

// Get all students
router.get('/students', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    db.query('SELECT id, name FROM student', (err, results) => {
        if (err) return res.status(500).json({ error: 'Error fetching students' });
        res.json(results);
    });
});
// Manage Departments
app.post('/api/admin/add-department', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { dept_name, building, budget } = req.body;
    db.query("INSERT INTO department VALUES (?, ?, ?)", [dept_name, building, budget], (err) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Department added successfully!" });
    });
});
// Update Department
app.put('/api/admin/update-departments/:dept_name', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { dept_name } = req.params;
    const { building, budget } = req.body;

    if (!building || !budget) {
        return res.status(400).json({ error: 'Building and budget are required' });
    }

    const query = 'UPDATE department SET building = ?, budget = ? WHERE dept_name = ?';
    db.query(query, [building, budget, dept_name], (err, result) => {
        if (err) {
            console.error('Error updating department:', err);
            return res.status(500).json({ error: 'Internal Server Error' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Department not found' });
        }
        res.status(200).json({ message: 'Department updated successfully' });
    });
});

// Update Course
app.put('/api/admin/courses/:course_id', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { course_id } = req.params;
    const { title, credits, dept_name } = req.body;

    if (!title || !credits || !dept_name) {
        return res.status(400).json({ error: 'Title, credits, and department name are required' });
    }

    const query = 'UPDATE course SET title = ?, credits = ?, dept_name = ? WHERE course_id = ?';
    db.query(query, [title, credits, dept_name, course_id], (err, result) => {
        if (err) {
            console.error('Error updating course:', err);
            return res.status(500).json({ error: 'Internal Server Error' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Course not found' });
        }
        res.status(200).json({ message: 'Course updated successfully' });
    });
});

// Manage Courses
app.post('/api/admin/add-course', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { course_id, title, dept_name, credits } = req.body;
    db.query("INSERT INTO course VALUES (?, ?, ?, ?)", [course_id, title, dept_name, credits], (err) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Course added successfully!" });
    });
});
// POST: Add a new student
app.post('/api/admin/add-students', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { ID, name, dept_name, tot_cred } = req.body;

    if (!ID || !name || !dept_name || tot_cred === undefined) {
        return res.status(400).json({ error: 'ID, name, department, and total credits are required' });
    }

    const query = 'INSERT INTO student (ID, name, dept_name, tot_cred) VALUES (?, ?, ?, ?)';
    db.query(query, [ID, name, dept_name, tot_cred], (err) => {
        if (err) {
            console.error('Error adding student:', err);
            return res.status(500).json({ error: 'Internal Server Error' });
        }
        res.status(201).json({ message: 'Student added successfully!' });
    });
});
// PUT: Update a student by ID
app.put('/api/admin/students/:ID', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { ID } = req.params;
    const { name, dept_name, tot_cred } = req.body;

    if (!name || !dept_name || tot_cred === undefined) {
        return res.status(400).json({ error: 'Name, department, and total credits are required' });
    }

    const query = 'UPDATE student SET name = ?, dept_name = ?, tot_cred = ? WHERE ID = ?';
    db.query(query, [name, dept_name, tot_cred, ID], (err, result) => {
        if (err) {
            console.error('Error updating student:', err);
            return res.status(500).json({ error: 'Internal Server Error' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }
        res.status(200).json({ message: 'Student updated successfully!' });
    });
});

// Assign Instructors
app.post('/api/admin/assign-instructor', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { instructor_id, course_id, sec_id, semester, year } = req.body;
    db.query("INSERT INTO teaches VALUES (?, ?, ?, ?, ?)", [instructor_id, course_id, sec_id, semester, year], (err) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Instructor assigned successfully!" });
    });
});

// Enroll Students
app.post('/api/admin/enroll-student', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { student_id, course_id, sec_id, semester, year } = req.body;
    db.query("INSERT INTO takes VALUES (?, ?, ?, ?, ?)", [student_id, course_id, sec_id, semester, year], (err) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Student enrolled successfully!" });
    });
});
//Add Instructor
app.post('/api/instructors', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { ID, name, dept_name, salary } = req.body;
    db.query(
        'INSERT INTO instructor (ID, name, dept_name, salary) VALUES (?, ?, ?, ?)',
        [ID, name, dept_name, salary],
        (err) => {
            if (err) return res.status(500).json({ error: 'Error adding instructor', details: err });
            res.json({ message: 'Instructor added successfully' });
        }
    );
});
// Update Instructor
router.put('/instructors/:id', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { id } = req.params;
    const { name, dept_name, salary } = req.body;
    db.query(
        'UPDATE instructor SET name = ?, dept_name = ?, salary = ? WHERE ID = ?',
        [name, dept_name, salary, id],
        (err) => {
            if (err) return res.status(500).json({ error: 'Error updating instructor', details: err });
            res.json({ message: 'Instructor updated successfully' });
        }
    );
});

// Generate Reports
app.post('/api/admin/generate-report', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    db.query(req.body.query, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json(result);
    });
});

// ==================== INSTRUCTOR FUNCTIONALITIES ====================

// View Assigned Courses
app.get('/api/instructor/courses', authenticateToken, authorizeRole(['Instructor']), (req, res) => {
    db.query("SELECT * FROM teaches WHERE ID = ?", [req.user.instructor_id], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json(result);
    });
});

// Update Student Grades
app.put('/api/instructor/update-grade', authenticateToken, authorizeRole(['Instructor']), (req, res) => {
    const { student_id, course_id, sec_id, semester, year, grade } = req.body;
    db.query("UPDATE takes SET grade=? WHERE ID=? AND course_id=? AND sec_id=? AND semester=? AND year=?", 
    [grade, student_id, course_id, sec_id, semester, year], (err) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Grade updated successfully!" });
    });
});
router.get('/student/courses', authenticateToken, authorizeRole(['Student']), (req, res) => {
    const studentId = req.user.student_id;
    
    const query = `
        SELECT t.course_id, c.title, t.sec_id, t.semester, t.year, t.grade 
        FROM takes t 
        JOIN course c ON t.course_id = c.course_id 
        WHERE t.ID = ?`;
    
    db.query(query, [studentId], (err, results) => {
        if (err) return res.status(500).json({ error: 'Error fetching enrolled courses' });
        res.json(results);
    });
});
router.post('/student/select-advisor', authenticateToken, authorizeRole(['Student']), (req, res) => {
    const studentId = req.user.student_id;
    const { advisorId } = req.body;

    if (!advisorId) {
        return res.status(400).json({ error: 'Advisor ID is required' });
    }

    const query = `INSERT INTO advisor (s_ID, i_ID) VALUES (?, ?) ON DUPLICATE KEY UPDATE i_ID = ?`;
    
    db.query(query, [studentId, advisorId, advisorId], (err) => {
        if (err) return res.status(500).json({ error: 'Error selecting advisor' });
        res.json({ message: 'Advisor selected successfully' });
    });
});
router.get('/student/schedule', authenticateToken, authorizeRole(['Student']), (req, res) => {
    const studentId = req.user.student_id;

    const query = `
        SELECT s.course_id, s.sec_id, s.semester, s.year, c.title, s.building, s.room_number, ts.day, ts.start_time, ts.end_time 
        FROM takes t 
        JOIN section s ON t.course_id = s.course_id AND t.sec_id = s.sec_id AND t.semester = s.semester AND t.year = s.year
        JOIN course c ON s.course_id = c.course_id
        JOIN time_slot ts ON s.time_slot_id = ts.time_slot_id
        WHERE t.ID = ?`;

    db.query(query, [studentId], (err, results) => {
        if (err) return res.status(500).json({ error: 'Error fetching schedule' });
        res.json(results);
    });
});
router.get('/student/details', authenticateToken, authorizeRole(['Student']), (req, res) => {
    const studentId = req.user.student_id;

    const query = `SELECT ID, name, dept_name, tot_cred FROM student WHERE ID = ?`;

    db.query(query, [studentId], (err, result) => {
        if (err) return res.status(500).json({ error: 'Error fetching student details' });
        if (result.length === 0) return res.status(404).json({ error: 'Student not found' });
        res.json(result[0]);
    });
});

// ==================== STUDENT FUNCTIONALITIES ====================

// View Enrolled Courses
app.get('/api/student/courses', authenticateToken, authorizeRole(['Student']), (req, res) => {
    db.query("SELECT * FROM takes WHERE ID = ?", [req.user.student_id], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json(result);
    });
});

// Check Grades
app.get('/api/student/grades', authenticateToken, authorizeRole(['Student']), (req, res) => {
    db.query("SELECT course_id, sec_id, semester, year, grade FROM takes WHERE ID = ?", [req.user.student_id], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json(result);
    });
});
//Find Advisor
router.get('/student/advisor', authenticateToken, authorizeRole(['Student']), (req, res) => {
    const studentID = req.user.student_id;
    db.query("SELECT i_ID FROM advisor WHERE s_ID = ?", [studentID], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json(result);
    });
});
//Classroom Schedule
router.get('/student/classroom-schedule', authenticateToken, authorizeRole(['Student']), (req, res) => {
    const studentID = req.user.student_id;
    db.query(`SELECT sec.course_id, sec.sec_id, sec.building, sec.room_number 
              FROM takes t JOIN section sec ON t.course_id = sec.course_id 
              WHERE t.ID = ?`, [studentID], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json(result);
    });
});
// Delete Department by dept_name
router.delete('/departments/:dept_name', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { dept_name } = req.params;
    db.query('DELETE FROM department WHERE dept_name = ?', [dept_name], (err, result) => {
        if (err) return res.status(500).json({ error: 'Error deleting department' });
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Department not found' });
        res.json({ message: 'Department deleted successfully' });
    });
});

// Delete Student by student ID
router.delete('/students/:id', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM student WHERE ID = ?', [id], (err, result) => {
        if (err) return res.status(500).json({ error: 'Error deleting student' });
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Student not found' });
        res.json({ message: 'Student deleted successfully' });
    });
});

// Delete Course by course_id
router.delete('/courses/:course_id', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { course_id } = req.params;
    db.query('DELETE FROM course WHERE course_id = ?', [course_id], (err, result) => {
        if (err) return res.status(500).json({ error: 'Error deleting course' });
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Course not found' });
        res.json({ message: 'Course deleted successfully' });
    });
});

// Delete Instructor by instructor ID
router.delete('/instructors/:id', authenticateToken, authorizeRole(['Admin']), (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM instructor WHERE ID = ?', [id], (err, result) => {
        if (err) return res.status(500).json({ error: 'Error deleting instructor' });
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Instructor not found' });
        res.json({ message: 'Instructor deleted successfully' });
    });
});


app.use('/api', router);
// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});
