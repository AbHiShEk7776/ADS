import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-VTGR2OFT.js";
import "./chunk-ECZWEC6A.js";
import "./chunk-US3C7B2U.js";
import "./chunk-AQYIT73X.js";
import "./chunk-YHCV7DAQ.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
