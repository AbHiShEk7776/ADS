import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-home',
  standalone: true,
  
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  imports: [RouterModule,CommonModule] // Import RouterModule for navigation
})
export class HomeComponent {
  isAuthenticated = false;

  constructor(private router: Router, private authService: AuthService) {}

  ngOnInit() {
    this.isAuthenticated = this.authService.isAuthenticated();
    
    // ✅ If already logged in, redirect to the role-based dashboard
    if (this.isAuthenticated) {
      const role = this.authService.getUserRole();
      this.redirectToDashboard(role);
    }
  }

  navigateToLogin(role: string) {
    this.router.navigate(['/login'], { queryParams: { role } });
  }

  redirectToDashboard(role: string) {
    switch (role) {
      case 'Admin':
        this.router.navigate(['/admin']);
        break;
      case 'Instructor':
        this.router.navigate(['/instructor']);
        break;
      case 'Student':
        this.router.navigate(['/student']);
        break;
      default:
        this.router.navigate(['/dashboard']);
    }
  }
}
