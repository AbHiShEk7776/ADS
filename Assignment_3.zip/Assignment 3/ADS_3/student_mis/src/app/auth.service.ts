import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, catchError, tap, throwError } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';


@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = 'http://localhost:5000/api/auth'; // Ensure consistent API path
  private tokenKey = 'auth_token';
  private roleKey = 'user_role';
  private usernameKey = 'username';
  isLoggedIn = new BehaviorSubject<boolean>(false);

  constructor(
    private http: HttpClient,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: object
  ) {
    // Initialize login status from local storage
    if (isPlatformBrowser(this.platformId)) {
      this.isLoggedIn.next(!!localStorage.getItem(this.tokenKey));
    }
  }

  /**
   * Login method
   * @param username User's username
   * @param password User's password
   * @returns Observable<{ token: string; role: string; username: string }>
   */
  login(username: string, password: string): Observable<{ token: string; role: string; username: string }> {
    return this.http
      .post<{ token: string; role: string; username: string }>(
        `${this.apiUrl}/login`,
        { username, password }
      )
      .pipe(
        tap((res) => {
          this.storeUserData(res.token, res.role, res.username);
          this.isLoggedIn.next(true);
          this.redirectBasedOnRole(res.role);
        }),
        catchError((err) => {
          console.error('Login Error:', err);
          return throwError(() => new Error('Login failed. Please check your credentials.'));
        })
      );
  }

  /**
   * Register method
   * @param username User's username
   * @param password User's password
   * @param role User's role (Admin/Instructor/Student)
   * @param linkedId Optional linked ID for students/instructors
   * @returns Observable<{ message: string }>
   */
  register(username: string, password: string, role: string, linkedId?: string): Observable<{ message: string }> {
    return this.http
      .post<{ message: string }>(`${this.apiUrl}/register`, {
        username,
        password,
        role,
        linked_id: linkedId || null,
      })
      .pipe(
        tap(() => {
          alert('Registration successful! Please log in.');
          this.router.navigate(['/login']);
        }),
        catchError((err) => {
          console.error('Registration Error:', err);
          return throwError(() => new Error(err.error?.message || 'Registration failed. Try again.'));
        })
      );
  }

  /**
   * Logout method - Clear storage and redirect to login
   */
  logout(): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem(this.tokenKey);
      localStorage.removeItem(this.roleKey);
      localStorage.removeItem(this.usernameKey);
      this.isLoggedIn.next(false);
    }
    this.router.navigate(['/login']);
  }

  /**
   * Store user data securely in local storage
   */
  private storeUserData(token: string, role: string, username: string): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem(this.tokenKey, token);
      localStorage.setItem(this.roleKey, role);
      localStorage.setItem(this.usernameKey, username);
    }
  }

  /**
   * Retrieve JWT token from local storage
   * @returns JWT Token or null
   */
  getToken(): string | null {
    return isPlatformBrowser(this.platformId) ? localStorage.getItem(this.tokenKey) : null;
  }

  /**
   * Get user role
   * @returns User role (Admin, Instructor, Student)
   */
  getUserRole(): string {
    return isPlatformBrowser(this.platformId) ? localStorage.getItem(this.roleKey) || '' : '';
  }

  /**
   * Check if user is authenticated
   * @returns boolean
   */
  isAuthenticated(): boolean {
    return !!this.getToken();
  }

  /**
   * Redirect user based on their role
   * @param role User's role (Admin/Instructor/Student)
   */
  private redirectBasedOnRole(role: string) {
    const routes: Record<string, string> = {
      Admin: '/admin',
      Instructor: '/instructor',
      Student: '/student',
    };
  
    this.router.navigate([routes[role] || '/dashboard']);
  }
}
