import { Component } from '@angular/core';
import { AuthService } from '../auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html', 
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username = '';
  password = '';
  errorMessage: string | null = null;

  constructor(private authService: AuthService,private router: Router) {}

  login() {
    // Input Validation
    if (!this.username.trim() || !this.password.trim()) {
      this.errorMessage = 'Username and password are required!';
      return;
    }

    // Call AuthService login method
    this.authService.login(this.username, this.password).subscribe({
      next: (response: any) => {
        // Store JWT token
        localStorage.setItem('token', response.token);
        console.log(response.token);

        // Navigate to the admin dashboard (or other secure page)
        this.router.navigate(['/admin']);
      },
      error: (error) => {
        console.error('Login failed:', error);
        this.errorMessage = 'Invalid credentials or server error.';
      },
    });
  }

  clearError() {
    this.errorMessage = null;
  }
}
