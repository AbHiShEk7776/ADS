import { Component } from '@angular/core';
import { AuthService } from '../auth.service';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule,MatButtonModule,MatToolbarModule],
  templateUrl: './navbar.component.html', // ✅ Correct format
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  role = '';

  constructor(private authService: AuthService) {
    this.role = authService.getUserRole() || '';
  }

  logout() {
    this.authService.logout();
  }
}