import { Component ,OnInit} from '@angular/core';
import { AuthService } from './auth.service';
import { RouterOutlet } from '@angular/router';
import { StudentComponent } from './student/student.component';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { AdminComponent } from './admin/admin.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { InstructorComponent } from './instructor/instructor.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,RegisterComponent,StudentComponent,CommonModule,LoginComponent,NavbarComponent,FooterComponent,AdminComponent,DashboardComponent,InstructorComponent,HomeComponent],
  templateUrl:'./app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  isAuthenticated = false;
  userRole = '';

  constructor(private authService: AuthService) {}

  ngOnInit() {
    // Subscribe to authentication state changes
    this.authService.isLoggedIn.subscribe((loggedIn) => {
      this.isAuthenticated = loggedIn;
      this.userRole = this.authService.getUserRole();
    });

    // Initialize authentication state
    this.isAuthenticated = this.authService.isAuthenticated();
    this.userRole = this.authService.getUserRole();
  }

  logout() {
    this.authService.logout();
  }
}

