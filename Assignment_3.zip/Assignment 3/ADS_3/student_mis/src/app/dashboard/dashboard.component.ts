import { Component,OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports:[CommonModule,RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  userRole: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    this.userRole = this.authService.getUserRole(); // Get the logged-in user role
  }

  // Navigate based on role
  goToAdmin() {
    this.router.navigate(['/admin']);
  }

  goToInstructor() {
    this.router.navigate(['/instructor']);
  }

  goToStudent() {
    this.router.navigate(['/student']);
  }
}
