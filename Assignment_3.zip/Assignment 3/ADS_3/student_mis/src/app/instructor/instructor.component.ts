import { Component } from '@angular/core';

@Component({
  selector: 'app-instructor',
  standalone: true,
  templateUrl: './instructor.component.html',
  styleUrls: ['./instructor.component.css']
})
export class InstructorComponent {}
