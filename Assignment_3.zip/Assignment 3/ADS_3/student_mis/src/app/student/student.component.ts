import { Component, OnInit } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-student',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css'],
})
export class StudentComponent implements OnInit {
  apiUrl = 'http://localhost:5000/api';
  
  studentDetails: any = null; // Stores student personal details
  studentCourses: any[] = []; // Stores student enrolled courses and grades
  studentSchedule: any[] = []; // Stores student classroom schedule
  instructors: any[] = []; // Stores available instructors for advisor assignment
  
  selectedInstructor: string = ''; // Selected advisor for assignment
  studentId: string = 'S001'; // Replace with logged-in student's ID

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchStudentDetails();
    this.fetchInstructors();
    this.viewCourses();
    this.viewSchedule();
  }
 getAuthHeaders() {
    const token = localStorage.getItem('token');
    console.log(token); // Ensure the token is stored during login
    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
  }
  // Fetch Student Personal Details
  fetchStudentDetails() {
    this.http.get(`${this.apiUrl}/student/details`)
      .subscribe((data: any) => {
        this.studentDetails = data;
      }, error => {
        console.error('Error fetching student details:', error);
      });
  }

  // Fetch Instructors (For Advisor Selection)
  fetchInstructors() {
    this.http.get(`${this.apiUrl}/student/advisors`,{headers: this.getAuthHeaders()})
      .subscribe((data: any) => {
        this.instructors = data;
      }, error => {
        console.error('Error fetching instructors:', error);
      });
  }

  // View Enrolled Courses and Grades
  viewCourses() {
    this.http.get(`${this.apiUrl}/student/courses`,{headers: this.getAuthHeaders()})
      .subscribe((data: any) => {
        this.studentCourses = data; // Populate the courses array
      }, error => {
        console.error('Error fetching student courses:', error);
      });
  }
  // View Classroom Schedule
  viewSchedule() {
    this.http.get(`${this.apiUrl}/student/schedule`,{headers: this.getAuthHeaders()})
      .subscribe((data: any) => {
        this.studentSchedule = data;
      }, error => {
        console.error('Error fetching student schedule:', error);
      });
  }

  // Assign Advisor
  assignAdvisor() {
    if (!this.selectedInstructor) {
      alert('Please select an instructor');
      return;
    }

    const advisorData = {
      s_ID: this.studentId,
      i_ID: this.selectedInstructor,
    };

    this.http.post(`${this.apiUrl}/student/select-advisor`, advisorData,{headers: this.getAuthHeaders()})
      .subscribe(() => {
        alert('Advisor assigned successfully');
      }, error => {
        console.error('Error assigning advisor:', error);
      });
  }
}
