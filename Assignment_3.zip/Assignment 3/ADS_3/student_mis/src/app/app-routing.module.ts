import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { LoginComponent } from './login/login.component';
// import { DashboardComponent } from './dashboard.component';
// import { AdminComponent } from './admin.component';
// import { InstructorComponent } from './instructor.component';
// import { StudentComponent } from './student.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
//   { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
//   { path: 'admin', component: AdminComponent, canActivate: [AuthGuard] },
//   { path: 'instructor', component: InstructorComponent, canActivate: [AuthGuard] },
//   { path: 'student', component: StudentComponent, canActivate: [AuthGuard] },
  { path: '**', redirectTo: 'login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}