import { Injectable, inject } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class RoleGuard implements CanActivate {
  private authService = inject(AuthService);
  private router = inject(Router);

  canActivate(route: ActivatedRouteSnapshot): boolean {
    const expectedRole = route.data['role']; // 🔹 Expected role from route
    const userRole = this.authService.getUserRole(); // 🔹 Get stored role

    if (userRole && userRole.toLowerCase() === expectedRole.toLowerCase()) {
      return true; // ✅ Allow access if role matches
    } else {
      this.router.navigate(['/dashboard']); // 🔹 Redirect if role mismatch
      return false;
    }
  }
}
