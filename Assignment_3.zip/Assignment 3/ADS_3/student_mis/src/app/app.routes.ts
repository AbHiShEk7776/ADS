import { Routes, provideRouter } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { RoleGuard } from './role.guard';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { StudentComponent } from './student/student.component';
import { InstructorComponent } from './instructor/instructor.component';
import { AdminComponent } from './admin/admin.component';

export const routes: Routes = [
  { path: '', component: HomeComponent }, // Default route to Home page
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },

  // Role-Based Routing
  { path: 'student', component: StudentComponent, canActivate: [AuthGuard, RoleGuard], data: { role: 'student' } },
  { path: 'instructor', component: InstructorComponent, canActivate: [AuthGuard, RoleGuard], data: { role: 'instructor' } },
  { path: 'admin', component: AdminComponent, canActivate: [AuthGuard, RoleGuard], data: { role: 'admin' } },

  { path: '**', redirectTo: '' } // Redirect unknown routes to Home page
];

export const appRouting = provideRouter(routes);
