import { Component, OnInit } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-admin',
  imports: [CommonModule, FormsModule],
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  private apiUrl = 'http://localhost:5000/api';

  username: string = '';
  password: string = '';
  role: string = 'Student';
  student_id: number | null = null;
  instructor_id: number | null = null;

  dept_name: string = '';
  building: string = '';
  budget: number | null = null;

  course_id: string = '';
  title: string = '';
  credits: number | null = null;

  selectedStudentId: number | null = null;
  selectedInstructorId: number | null = null;
  selectedCourseId: string = '';
  selectedSectionId: string = '';
  semester: string = '';
  year: number | null = null;

  students: any[] = [];
  instructors: any[] = [];
  departments: any[] = [];
  courses: any[] = [];
  sections: any[] = [];

  showDepartments: boolean = false;
    showCourses: boolean = false;
    showStudents: boolean = false;
    showSections: boolean = false;
    showInstructors: boolean = false;

    selectedCourse: any = null;
selectedDepartment: any = null;

instructorData = { ID: '', name: '', dept_name: '', salary: 0 };
isEditingInstructor: boolean = false;
showAddInstructorModal: boolean = false;
showAssignInstructorModal: boolean = false;
departmentData = { dept_name: '', building: '', budget: 0 };
courseData = { course_id: '', title: '', credits: 0, dept_name: '' };

isEditingDepartment: boolean = false;
isEditingCourse: boolean = false;
studentData = {
  ID: '',
  name: '',
  dept_name: '',
  course_id: '',
  tot_cred: 0,
};
isEditingStudent = false;


  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchStudents();
    this.fetchInstructors();
    this.fetchDepartments();
    this.fetchCourses();
    this.fetchSections();
  }
  getAuthHeaders() {
    const token = localStorage.getItem('token');
    console.log(token); // Ensure the token is stored during login
    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
  }

  openModal(modalId: string) {
    const modal = document.getElementById(modalId);
    if (modal) modal.style.display = 'block';
  }

  closeModal(modalId: string) {
    const modal = document.getElementById(modalId);
    if (modal) modal.style.display = 'none';
  }

  createUser() {
    const payload: any = {
      username: this.username,
      password: this.password,
      role: this.role
    };

    if (this.role === 'Student') {
      payload.student_id = this.student_id;
    } else if (this.role === 'Instructor') {
      payload.instructor_id = this.instructor_id;
    }

    this.http.post(`${this.apiUrl}/admin/create-user`, payload,{headers: this.getAuthHeaders()}).subscribe(response => {
      alert('User created successfully');
    });
  }

  toggleDepartments(): void {
    this.showDepartments = !this.showDepartments;
}

toggleCourses(): void {
    this.showCourses = !this.showCourses;
}

toggleStudents(): void {
    this.showStudents = !this.showStudents;
}

toggleSections(): void {
    this.showSections = !this.showSections;
}

toggleInstructors(): void {
    this.showInstructors = !this.showInstructors;
}

  fetchStudents() {
    this.http.get<any[]>(`${this.apiUrl}/students`, { headers: this.getAuthHeaders() })
      .subscribe(
        data => (this.students = data),
        error => console.error('Error fetching students:', error)
      );
  }
  
  fetchInstructors() {
    this.http.get<any[]>(`${this.apiUrl}/instructors`, { headers: this.getAuthHeaders() })
      .subscribe(
        data => (this.instructors = data),
        error => console.error('Error fetching instructors:', error)
      );
  }
  
  fetchDepartments() {
    this.http.get<any[]>(`${this.apiUrl}/departments`, { headers: this.getAuthHeaders() })
      .subscribe(
        data => (this.departments = data),
        error => console.error('Error fetching departments:', error)
      );
  }
  
  fetchCourses() {
    this.http.get<any[]>(`${this.apiUrl}/courses`, { headers: this.getAuthHeaders() })
      .subscribe(
        data => (this.courses = data),
        error => console.error('Error fetching courses:', error)
      );
  }
  
  fetchSections() {
    this.http.get<any[]>(`${this.apiUrl}/sections`, { headers: this.getAuthHeaders() })
      .subscribe(
        data => (this.sections = data),
        error => console.error('Error fetching sections:', error)
      );
  }
  

  saveDepartment() {
    if (this.isEditingDepartment) {
      // Update Department
      this.http.put(`${this.apiUrl}/admin/update-departments/${this.departmentData.dept_name}`, this.departmentData, { headers: this.getAuthHeaders() })
        .subscribe(() => {
          alert('Department updated successfully');
          this.fetchDepartments();
          this.closeModal('departmentModal');
        });
    } else {
      // Add Department
      this.http.post(`${this.apiUrl}/admin/add-departments`, this.departmentData, { headers: this.getAuthHeaders() })
        .subscribe(() => {
          alert('Department added successfully');
          this.fetchDepartments();
          this.closeModal('departmentModal');
        });
    }
    this.resetDepartmentForm();
  }
  
  // Edit Department (Open Modal in Edit Mode)
  editDepartment(department: any) {
    this.isEditingDepartment = true;
    this.departmentData = { ...department };
    this.openModal('departmentModal');
  }
  
  // Reset Department Form
  resetDepartmentForm() {
    this.departmentData = { dept_name: '', building: '', budget: 0 };
    this.isEditingDepartment = false;
  }
  
  // Add/Edit Course
  saveCourse() {
    if (this.isEditingCourse) {
      // Update Course
      this.http.put(`${this.apiUrl}/admin/courses/${this.courseData.course_id}`, this.courseData, { headers: this.getAuthHeaders() })
        .subscribe(() => {
          alert('Course updated successfully');
          this.fetchCourses();
          this.closeModal('courseModal');
        });
    } else {
      // Add Course
      this.http.post(`${this.apiUrl}/courses`, this.courseData, { headers: this.getAuthHeaders() })
        .subscribe(() => {
          alert('Course added successfully');
          this.fetchCourses();
          this.closeModal('courseModal');
        });
    }
    this.resetCourseForm();
  }
  
  // Edit Course (Open Modal in Edit Mode)
  editCourse(course: any) {
    this.isEditingCourse = true;
    this.courseData = { ...course };
    this.openModal('courseModal');
  }
  
  // Reset Course Form
  resetCourseForm() {
    this.courseData = { course_id: '', title: '', credits: 0, dept_name: '' };
    this.isEditingCourse = false;
  }
  saveStudent() {
    if (!this.studentData.ID || !this.studentData.name || !this.studentData.course_id || !this.studentData.dept_name || this.studentData.tot_cred === null) {
      alert('All fields (ID, name, course, department, and total credits) are required');
      return;
    }
  
    if (this.isEditingStudent) {
      // ✅ Update Student
      this.http.put(`${this.apiUrl}/admin/update-students/${this.studentData.ID}`, this.studentData, { headers: this.getAuthHeaders() })
        .subscribe(() => {
          alert('Student updated successfully');
          this.fetchStudents(); // Refresh the student list
          this.closeModal('enrollStudentModal'); // Close the modal
        }, error => {
          alert('Error updating student');
          console.error('Error updating student:', error);
        });
    } else {
      // ✅ Add Student
      this.http.post(`${this.apiUrl}/admin/add-students`, this.studentData, { headers: this.getAuthHeaders() })
        .subscribe(() => {
          alert('Student added successfully');
          this.fetchStudents(); // Refresh the student list
          this.closeModal('enrollStudentModal'); // Close the modal
        }, error => {
          alert('Error adding student');
          console.error('Error adding student:', error);
        });
    }
    this.resetStudentForm(); // Clear the form
  }
  
  // ✅ Edit Student (Open Modal in Edit Mode)
  editStudent(student: any) {
    this.isEditingStudent = true;
    this.studentData = { ...student }; // Populate form with student data
    this.openModal('enrollStudentModal'); // Open the modal
  }
  
  // ✅ Reset Student Form
  resetStudentForm() {
    this.studentData = { ID: '', name: '', course_id: '', dept_name: '', tot_cred: 0 }; // Clear all fields
    this.isEditingStudent = false; // Reset editing mode
  }
  
  
  enrollStudent() {
    const payload = {
      student_id: this.selectedStudentId,
      course_id: this.selectedCourseId,
      sec_id: this.selectedSectionId,
      semester: this.semester,
      year: this.year
    };

    this.http.post(`${this.apiUrl}/enroll`, payload).subscribe(response => {
      alert('Student enrolled successfully');
      this.closeModal('enrollStudentModal');
    });
  }
  saveInstructor() {
    if (this.isEditingInstructor) {
      this.http.put(`${this.apiUrl}/instructors/${this.instructorData.ID}`, this.instructorData, { headers: this.getAuthHeaders() })
        .subscribe(() => {
          alert('Instructor updated successfully');
          this.fetchInstructors();
          this.closeModal('addInstructorModal');
        });
    } else {
      this.http.post(`${this.apiUrl}/instructors`, this.instructorData, { headers: this.getAuthHeaders() })
        .subscribe(() => {
          alert('Instructor added successfully');
          this.fetchInstructors();
          this.closeModal('addInstructorModal');
        });
    }
  }
  
  // Edit Instructor (Open Edit Modal)
  editInstructor(instructor: any) {
    this.isEditingInstructor = true;
    this.instructorData = { ...instructor };
    this.openModal('addInstructorModal');
  }
  
  // Delete Instructor
  deleteInstructor(id: string) {
    if (confirm('Are you sure you want to delete this instructor?')) {
      this.http.delete(`${this.apiUrl}/instructors/${id}`, { headers: this.getAuthHeaders() })
        .subscribe(() => {
          alert('Instructor deleted successfully');
          this.fetchInstructors();
        });
    }
  }
  assignInstructor() {
    const payload = {
      instructor_id: this.selectedInstructorId,
      course_id: this.selectedCourseId,
      sec_id: this.selectedSectionId,
      semester: this.semester,
      year: this.year
    };

    this.http.post(`${this.apiUrl}/assign-instructor`, payload).subscribe(response => {
      alert('Instructor assigned successfully');
      this.closeModal('assignInstructorModal');
    });
  }
  deleteDepartment(deptName: string) {
    if (confirm(`Are you sure you want to delete the department: ${deptName}?`)) {
      this.http.delete(`${this.apiUrl}/departments/${deptName}`, { headers: this.getAuthHeaders() })
        .subscribe(
          () => {
            console.log('Department deleted successfully');
            this.fetchDepartments();
          },
          error => console.error('Error deleting department:', error)
        );
    }
  }
  deleteCourse(courseId: string) {
    if (confirm(`Are you sure you want to delete the course: ${courseId}?`)) {
      this.http.delete(`${this.apiUrl}/courses/${courseId}`, { headers: this.getAuthHeaders() })
        .subscribe(
          () => {
            console.log('Course deleted successfully');
            this.fetchCourses();
          },
          error => console.error('Error deleting course:', error)
        );
    }
  }
  deleteStudent(studentId: string) {
    if (confirm(`Are you sure you want to delete the student: ${studentId}?`)) {
      this.http.delete(`${this.apiUrl}/students/${studentId}`, { headers: this.getAuthHeaders() })
        .subscribe(
          () => {
            console.log('Student deleted successfully');
            this.fetchStudents(); // Refresh student list after deletion
          },
          (error) => console.error('Error deleting student:', error)
        );
    }
  }
  

  generateReport() {
    this.http.get(`${this.apiUrl}/reports`).subscribe(response => {
      alert('Report generated');
    });
  }
}
