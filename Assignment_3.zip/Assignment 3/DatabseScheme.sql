	-- Create the database
	CREATE DATABASE university;
	USE university;

	-- Classroom table
	CREATE TABLE classroom (
		building VARCHAR(15),
		room_number VARCHAR(7),
		capacity NUMERIC(4, 0),
		PRIMARY KEY (building, room_number)
	);

	-- Department table
	CREATE TABLE department (
		dept_name VARCHAR(20),
		building VARCHAR(15),
		budget NUMERIC(12, 2) CHECK (budget > 0),
		PRIMARY KEY (dept_name)
	);

	-- Course table
	CREATE TABLE course (
		course_id VARCHAR(8),
		title VARCHAR(50),
		dept_name VARCHAR(20),
		credits NUMERIC(2, 0),
		PRIMARY KEY (course_id),
		FOREIGN KEY (dept_name) REFERENCES department(dept_name)
	);

	-- Instructor table
	CREATE TABLE instructor (
		ID VARCHAR(5),
		name VARCHAR(20),
		dept_name VARCHAR(20),
		salary NUMERIC(8, 2),
		PRIMARY KEY (ID),
		FOREIGN KEY (dept_name) REFERENCES department(dept_name)
	);

	-- Student table
	CREATE TABLE student (
		ID VARCHAR(5),
		name VARCHAR(20),
		dept_name VARCHAR(20),
		tot_cred NUMERIC(3, 0),
		PRIMARY KEY (ID),
		FOREIGN KEY (dept_name) REFERENCES department(dept_name)
	);

	-- Section table
	CREATE TABLE section (
		course_id VARCHAR(8),
		sec_id VARCHAR(8),
		semester VARCHAR(6),
		year NUMERIC(4, 0),
		building VARCHAR(15),
		room_number VARCHAR(7),
		time_slot_id VARCHAR(4),
		PRIMARY KEY (course_id, sec_id, semester, year),
		FOREIGN KEY (course_id) REFERENCES course(course_id),
		FOREIGN KEY (building, room_number) REFERENCES classroom(building, room_number)
	);

	-- Teaches table
	CREATE TABLE teaches (
		ID VARCHAR(5),
		course_id VARCHAR(8),
		sec_id VARCHAR(8),
		semester VARCHAR(6),
		year NUMERIC(4, 0),
		PRIMARY KEY (ID, course_id, sec_id, semester, year),
		FOREIGN KEY (ID) REFERENCES instructor(ID),
		FOREIGN KEY (course_id, sec_id, semester, year) REFERENCES section(course_id, sec_id, semester, year)
	);

	-- Takes table
	CREATE TABLE takes (
		ID VARCHAR(5),
		course_id VARCHAR(8),
		sec_id VARCHAR(8),
		semester VARCHAR(6),
		year NUMERIC(4, 0),
		grade VARCHAR(2),
		PRIMARY KEY (ID, course_id, sec_id, semester, year),
		FOREIGN KEY (ID) REFERENCES student(ID),
		FOREIGN KEY (course_id, sec_id, semester, year) REFERENCES section(course_id, sec_id, semester, year)
	);

	-- Advisor table
	CREATE TABLE advisor (
		s_ID VARCHAR(5),
		i_ID VARCHAR(5),
		PRIMARY KEY (s_ID),
		FOREIGN KEY (s_ID) REFERENCES student(ID),
		FOREIGN KEY (i_ID) REFERENCES instructor(ID)
	);

	-- Time Slot table
	CREATE TABLE time_slot (
		time_slot_id VARCHAR(4),
		day VARCHAR(1),
		start_time TIME,
		end_time TIME,
		PRIMARY KEY (time_slot_id, day, start_time)
	);

	-- Prerequisite table
	CREATE TABLE prereq (
		course_id VARCHAR(8),
		prereq_id VARCHAR(8),
		PRIMARY KEY (course_id, prereq_id),
		FOREIGN KEY (course_id) REFERENCES course(course_id),
		FOREIGN KEY (prereq_id) REFERENCES course(course_id)
	);
    CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'Instructor', 'Student') NOT NULL,
    student_id VARCHAR(5),   -- Specifically for students
    instructor_id VARCHAR(5), -- Specifically for instructors
    FOREIGN KEY (student_id) REFERENCES student(ID) ON DELETE CASCADE,
    FOREIGN KEY (instructor_id) REFERENCES instructor(ID) ON DELETE CASCADE
);
INSERT INTO classroom (building, room_number, capacity) VALUES
('Engineering', 'E101', 100),
('Science', 'S202', 80),
('Business', 'B303', 120),
('Arts', 'A404', 60),
('Law', 'L505', 90);
INSERT INTO department (dept_name, building, budget) VALUES
('Physics', 'Science', 400000.00),
('Business', 'Business', 600000.00),
('Literature', 'Arts', 300000.00),
('Law', 'Law', 450000.00);
INSERT INTO course (course_id, title, dept_name, credits) VALUES
('CS101', 'Introduction to Programming', 'Computer Science', 4),
('CS102', 'Database Management', 'Computer Science', 3),
('PH101', 'Classical Mechanics', 'Physics', 4),
('BA201', 'Principles of Marketing', 'Business', 3),
('LA301', 'Constitutional Law', 'Law', 4);
INSERT INTO instructor (ID, name, dept_name, salary) VALUES
('I1001', 'Dr. Alice', 'Computer Science', 120000.00),
('I1002', 'Dr. Bob', 'Physics', 110000.00),
('I1003', 'Dr. Carol', 'Business', 115000.00),
('I1004', 'Dr. Dave', 'Literature', 95000.00),
('I1005', 'Dr. Eve', 'Law', 130000.00);
INSERT INTO student (ID, name, dept_name, tot_cred) VALUES
('S2001', 'John Doe', 'Computer Science', 30),
('S2002', 'Jane Smith', 'Physics', 28),
('S2003', 'Mike Brown', 'Business', 32),
('S2004', 'Sara Lee', 'Literature', 26),
('S2005', 'Tom Wilson', 'Law', 29);
INSERT INTO section (course_id, sec_id, semester, year, building, room_number, time_slot_id) VALUES
('CS101', '01', 'Fall', 2023, 'Engineering', 'E101', 'A1'),
('CS102', '02', 'Spring', 2024, 'Engineering', 'E101', 'B2'),
('PH101', '01', 'Fall', 2023, 'Science', 'S202', 'C3'),
('BA201', '03', 'Spring', 2024, 'Business', 'B303', 'D4'),
('LA301', '01', 'Fall', 2023, 'Law', 'L505', 'E5');

INSERT INTO teaches (ID, course_id, sec_id, semester, year) VALUES
('I1001', 'CS101', '01', 'Fall', 2023),
('I1001', 'CS102', '02', 'Spring', 2024),
('I1002', 'PH101', '01', 'Fall', 2023),
('I1003', 'BA201', '03', 'Spring', 2024),
('I1005', 'LA301', '01', 'Fall', 2023);
INSERT INTO takes (ID, course_id, sec_id, semester, year, grade) VALUES
('S2001', 'CS101', '01', 'Fall', 2023, 'A'),
('S2002', 'PH101', '01', 'Fall', 2023, 'B+'),
('S2003', 'BA201', '03', 'Spring', 2024, 'A-'),
('S2004', 'LA301', '01', 'Fall', 2023, 'B'),
('S2005', 'CS102', '02', 'Spring', 2024, 'A');
INSERT INTO advisor (s_ID, i_ID) VALUES
('S2001', 'I1001'),
('S2002', 'I1002'),
('S2003', 'I1003'),
('S2004', 'I1004'),
('S2005', 'I1005');
INSERT INTO time_slot (time_slot_id, day, start_time, end_time) VALUES
('A1', 'M', '09:00:00', '10:30:00'),
('B2', 'T', '10:45:00', '12:15:00'),
('C3', 'W', '13:00:00', '14:30:00'),
('D4', 'R', '15:00:00', '16:30:00'),
('E5', 'F', '08:00:00', '09:30:00');
INSERT INTO prereq (course_id, prereq_id) VALUES
('CS102', 'CS101'),
('LA301', 'PH101');






