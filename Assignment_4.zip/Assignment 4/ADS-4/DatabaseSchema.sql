CREATE DATABASE mcq_exam_system;
USE mcq_exam_system;

-- Users table
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('teacher', 'student') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Exams table
CREATE TABLE exams (
    exam_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_name VARCHAR(100) NOT NULL,
    creator_id INT,
    duration INT NOT NULL, -- Duration in minutes
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (creator_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Questions table
CREATE TABLE questions (
    question_id INT AUTO_INCREMENT PRIMARY KEY,
    question_text TEXT NOT NULL,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Exam-Questions mapping table
CREATE TABLE exam_questions (
    exam_id INT,
    question_id INT,
    PRIMARY KEY (exam_id, question_id),
    FOREIGN KEY (exam_id) REFERENCES exams(exam_id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(question_id) ON DELETE CASCADE
);

-- Options table
CREATE TABLE options (
    option_id INT AUTO_INCREMENT PRIMARY KEY,
    question_id INT,
    option_text TEXT NOT NULL,
    is_correct BOOLEAN NOT NULL,
    FOREIGN KEY (question_id) REFERENCES questions(question_id) ON DELETE CASCADE
);

-- Student Exams (Score Tracking)
CREATE TABLE student_exams (
    student_exam_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    exam_id INT,
    score INT NOT NULL,
    taken_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (exam_id) REFERENCES exams(exam_id) ON DELETE CASCADE
);
ALTER TABLE exams MODIFY COLUMN duration INT NOT NULL DEFAULT 60;

INSERT INTO exams (exam_name, creator_id) VALUES
('Mathematics Test', 1),
('Science Quiz', 2);
INSERT INTO questions (question_text, created_by) VALUES
('What is 2 + 2?', 1),
('What is the capital of France?', 2),
('What is H2O commonly known as?', 2);
INSERT INTO exam_questions (exam_id, question_id) VALUES
(1, 1),  -- Mathematics Test includes "What is 2 + 2?"
(2, 2),  -- Science Quiz includes "What is the capital of France?"
(2, 3);  -- Science Quiz includes "What is H2O commonly known as?"
INSERT INTO options (question_id, option_text, is_correct) VALUES
(1, '3', 0),
(1, '4', 1),
(1, '5', 0),
(2, 'Berlin', 0),
(2, 'Paris', 1),
(2, 'Madrid', 0),
(3, 'Water', 1),
(3, 'Oxygen', 0),
(3, 'Hydrogen', 0);
INSERT INTO student_exams (student_id, exam_id, score) VALUES
(3, 1, 10),  -- student1 scored 10 in Mathematics Test
(4, 2, 8),   -- student2 scored 8 in Science Quiz
(5, 2, 7);   -- student3 scored 7 in Science Quiz
INSERT INTO users (username, password_hash, role) VALUES ('teacher1', '$2b$10$YDQ5DPlTSdmY46A.QDKaMOsx5gfxhKfDzS2xKS0O56K6APxfY3Gzy', 'teacher');
INSERT INTO users (username, password_hash, role) VALUES ('teacher2', '$2b$10$zyGRGSHs8c54nyBZq4L5Ous45daM1dqMaBn29qlMVbrVfGYToLrGW', 'teacher');
INSERT INTO users (username, password_hash, role) VALUES ('student1', '$2b$10$85kQDcQgL6vq74OYT8kKFeiKbdsILiXmhba3kLbRzOo3cofiAnAhG', 'student');
INSERT INTO users (username, password_hash, role) VALUES ('student2', '$2b$10$sBmoJ4ZgJ99RIx8sRZ2Qy.5BKr..3Hm8avlkwnKbTkNrbigZaz5ge', 'student');
INSERT INTO users (username, password_hash, role) VALUES ('student3', '$2b$10$N/PoItIzM/pgEgYfkeU7S.3j1p8bOlfAxpURP0Cs.2prTF9K67UXm', 'student');