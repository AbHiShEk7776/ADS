const mysql = require('mysql2');

const pool = mysql.createPool({
  host: 'localhost',
  user: '22510020',
  password: 'Ashura123@',
  database: 'mcq_exam_system',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
}).promise();  // <-- Add .promise() here

module.exports = pool;
