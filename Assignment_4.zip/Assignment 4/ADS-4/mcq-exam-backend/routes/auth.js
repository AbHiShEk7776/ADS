// routes/auth.js
const express = require('express');
const router = express.Router();
const pool = require('../db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors=require('cors')

router.use(cors())

router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const [user] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);
    
    if (user.length === 0) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const validPassword = await bcrypt.compare(password, user[0].password_hash);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const token = jwt.sign(
      { userId: user[0].user_id, role: user[0].role },
     "swankey",
      { expiresIn: '1h' }
    );

    res.json({ 
      token,
      role: user[0].role,
      message: 'Login successful'
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Registration Route

router.post('/register', async (req, res) => {
  const { username, password, role, email } = req.body;

  // Hash the password
  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    const [existingUser] = await pool.query('SELECT username FROM users WHERE username = ?', [username]);
    
    if (existingUser.length > 0) {
      return res.status(409).json({ error: 'Username already exists' });
    }

    await pool.query(
      'INSERT INTO users (username, password_hash, role, email) VALUES (?, ?, ?, ?)',
      [username, hashedPassword, role, email]
    );

    res.status(201).json({ message: 'User registered successfully' });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }

});



module.exports = router;
