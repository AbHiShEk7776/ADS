// routes/exams.js
const express = require('express');
const router = express.Router();
const pool = require('../db');
const authenticateToken = require('../middleware/auth');

// Create an exam
router.post('/', authenticateToken, (req, res) => {
  if (req.user.role !== 'Teacher') return res.sendStatus(403);

  const { exam_name, start_time, end_time, duration, is_fixed_time, question_ids } = req.body;
  const creator_id = req.user.user_id;

  // Insert exam
  pool.query(
    'INSERT INTO exams (exam_name, creator_id, start_time, end_time, duration, is_fixed_time) VALUES (?, ?, ?, ?, ?, ?)',
    [exam_name, creator_id, start_time, end_time, duration, is_fixed_time],
    (error, results) => {
      if (error) return res.status(500).json({ error: error.message });

      const exam_id = results.insertId;

      // Associate questions with exam
      const examQuestionQueries = question_ids.map(qid => {
        return new Promise((resolve, reject) => {
          pool.query(
            'INSERT INTO exam_questions (exam_id, question_id) VALUES (?, ?)',
            [exam_id, qid],
            (err, res) => {
              if (err) reject(err);
              else resolve(res);
            }
          );
        });
      });

      Promise.all(examQuestionQueries)
        .then(() => res.status(201).json({ message: 'Exam created successfully' }))
        .catch(err => res.status(500).json({ error: err.message }));
    }
  );
});

// Fetch available exams for students
router.get('/available', authenticateToken, (req, res) => {
  if (req.user.role !== 'Student') return res.sendStatus(403);

  const currentTime = new Date();

  pool.query(
    'SELECT * FROM exams WHERE (start_time <= ? AND end_time >= ?) OR is_fixed_time = FALSE',
    [currentTime, currentTime],
    (error, results) => {
      if (error) return res.status(500).json({ error: error.message });
      res.json(results);
    }
  );
});

module.exports = router;
