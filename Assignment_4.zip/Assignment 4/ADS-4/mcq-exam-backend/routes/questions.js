// routes/questions.js
const express = require('express');
const router = express.Router();
const pool = require('../db');
const authenticateToken = require('../middleware/auth');

// Create a question
router.post('/', authenticateToken, (req, res) => {
  if (req.user.role !== 'Teacher') return res.sendStatus(403);

  const { question_text, image_path, math_expression, options } = req.body;
  const created_by = req.user.user_id;

  // Insert question
  pool.query(
    'INSERT INTO questions (question_text, image_path, math_expression, created_by) VALUES (?, ?, ?, ?)',
    [question_text, image_path, math_expression, created_by],
    (error, results) => {
      if (error) return res.status(500).json({ error: error.message });

      const question_id = results.insertId;

      // Insert options
      const optionQueries = options.map(option => {
        return new Promise((resolve, reject) => {
          pool.query(
            'INSERT INTO options (question_id, option_text, is_correct) VALUES (?, ?, ?)',
            [question_id, option.option_text, option.is_correct],
            (err, res) => {
              if (err) reject(err);
              else resolve(res);
            }
          );
        });
      });

      Promise.all(optionQueries)
        .then(() => res.status(201).json({ message: 'Question created successfully' }))
        .catch(err => res.status(500).json({ error: err.message }));
    }
  );
});

// Fetch all questions
router.get('/', authenticateToken, (req, res) => {
  if (req.user.role !== 'Teacher') return res.sendStatus(403);

  pool.query('SELECT * FROM questions', (error, results) => {
    if (error) return res.status(500).json({ error: error.message });
    res.json(results);
  });
});

module.exports = router;
