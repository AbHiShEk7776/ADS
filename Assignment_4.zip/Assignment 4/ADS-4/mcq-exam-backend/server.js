
const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcrypt');
const authRoutes = require('./routes/auth');

const app = express();

const pool = require('./db')


app.use(bodyParser.json());
app.use(cors({
  origin: 'http://localhost:4200',
  credentials: true
}));


app.use('/api/auth', authRoutes);



const db = mysql.createConnection({
  host: 'localhost',
  user: '22510020', 
  password: 'Ashura123@', 
  database: 'mcq_exam_system' 
});


db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL database');
});


app.post('/register', async (req, res) => {
  try {
    const { username, password, role } = req.body;

    
    if (!['teacher', 'student'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role. Choose "teacher" or "student".' });
    }

    
    db.query('SELECT username FROM users WHERE username = ?', [username], async (err, results) => {
      if (err) return res.status(500).json({ error: 'Database error' });

      if (results.length > 0) {
        return res.status(409).json({ error: 'Username already exists' });
      }

      
      const hashedPassword = await bcrypt.hash(password, 10);

    
      const query = `INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)`;
      db.query(query, [username, hashedPassword, role], (err, results) => {
        if (err) {
          console.error('Error inserting user:', err);
          return res.status(500).json({ error: 'Server error' });
        }

        res.status(201).json({ message: 'User registered successfully' });
      });
    });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});




app.post('/exams', (req, res) => {
  const { exam_name, creator_id, duration } = req.body;
  const query = 'INSERT INTO exams (exam_name, creator_id, duration) VALUES (?, ?, ?)';
  
  db.query(query, [exam_name, creator_id, duration], (err, result) => {
      if (err) {
          console.error('Error creating exam:', err);
          return res.status(500).json({ error: 'Database error' });
      }
      res.status(201).json({ message: 'Exam created successfully', exam_id: result.insertId });
  });
});



app.post('/questions', (req, res) => {
  const { question_text, options } = req.body;
  
  const query = 'INSERT INTO questions (question_text) VALUES (?)';
  
  db.query(query, [question_text, exam_id], (err, result) => {
      if (err) {
          console.error('Error adding question:', err);
          return res.status(500).json({ error: 'Database error' });
      }
      
      const question_id = result.insertId;
      const optionQuery = 'INSERT INTO options (question_id, option_text, is_correct) VALUES ?';
      const optionValues = options.map(opt => [question_id, opt.option_text, opt.is_correct]);

      db.query(optionQuery, [optionValues], (err) => {
          if (err) {
              console.error('Error adding options:', err);
              return res.status(500).json({ error: 'Database error' });
          }
          res.status(201).json({ message: 'Question added successfully', question_id });
      });
  });
});

app.get('/exams', (req, res) => {
  db.query('SELECT * FROM exams', (err, results) => {
      if (err) {
          console.error('Error fetching exams:', err);
          return res.status(500).json({ error: 'Database error' });
      }
      res.json(results);
  });
});

app.post('/create-exam', async (req, res) => {
  try {
    const { exam_name, creator_id, duration } = req.body;

    const [result] = await pool.query(
      `INSERT INTO exams (exam_name, creator_id, duration) VALUES (?, ?, ?)`,
      [exam_name, creator_id, duration]
    );

    res.status(201).json({ exam_id: result.insertId, message: 'Exam created successfully' });
  } catch (error) {
    console.error('Error creating exam:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


app.post('/add-question-to-exam', async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const { question_text, created_by, exam_id, options } = req.body;

    
    const [questionResult] = await connection.query(
      `INSERT INTO questions (question_text, created_by) VALUES (?, ?)`,
      [question_text, created_by]
    );

    const question_id = questionResult.insertId;

   
    await connection.query(
      `INSERT INTO exam_questions (exam_id, question_id) VALUES (?, ?)`,
      [exam_id, question_id]
    );

   
    const optionValues = options.map(option => [question_id, option.option_text, option.is_correct]);
    await connection.query(
      `INSERT INTO options (question_id, option_text, is_correct) VALUES ?`,
      [optionValues]
    );

    await connection.commit();
    res.status(201).json({ message: 'Question and options added successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Error adding question and options:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  } finally {
    connection.release();
  }
});


app.post('/save-score', (req, res) => {
  const { exam_id, score } = req.body;
  
  db.query('INSERT INTO  student_exams (exam_id, score) VALUES (?, ?)', [exam_id, score], (err) => {
      if (err) {
          return res.status(500).json({ error: 'Error saving score' });
      }
      res.status(200).json({ message: 'Score saved successfully' });
  });
});


app.get('/exam/:exam_id', (req, res) => {
  const { exam_id } = req.params;

 
  db.query('SELECT * FROM exams WHERE exam_id = ?', [exam_id], (err, examResults) => {
    if (err) {
      return res.status(500).json({ error: 'Error fetching exam details' });
    }
    if (!examResults.length) {
      return res.status(404).json({ error: 'Exam not found' });
    }

    const exam = examResults[0];

    
    db.query('SELECT question_id FROM exam_questions WHERE exam_id = ?', [exam_id], (err, questionIds) => {
      if (err) {
        return res.status(500).json({ error: 'Error fetching question IDs' });
      }
      if (!questionIds.length) {
        return res.status(404).json({ error: 'No questions found for this exam' });
      }

      const questionIdsArray = questionIds.map(q => q.question_id);

      
      db.query('SELECT * FROM questions WHERE question_id IN (?)', [questionIdsArray], (err, questionResults) => {
        if (err) {
          return res.status(500).json({ error: 'Error fetching questions' });
        }

        
        db.query('SELECT * FROM options WHERE question_id IN (?)', [questionIdsArray], (err, optionsResults) => {
          if (err) {
            return res.status(500).json({ error: 'Error fetching options' });
          }

          
          const questionsWithOptions = questionResults.map(question => ({
            ...question,
            options: optionsResults.filter(option => option.question_id === question.question_id),
          }));
         
          exam.questions = questionsWithOptions;

          
          res.json(exam);
        });
      });
    });
  });
});




app.get('/student-exams/:examId', (req, res) => {
  const examId = req.params.examId;
  const sql = `
    SELECT u.username AS student_name, se.score
    FROM student_exams se
    JOIN users u ON se.student_id = u.user_id
    WHERE se.exam_id = ?
  `;
  db.query(sql, [examId], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});


// const users = [
//     { username: 'teacher1', role: 'teacher' },
//     { username: 'teacher2', role: 'teacher' },
//     { username: 'student1', role: 'student' },
//     { username: 'student2', role: 'student' },
//     { username: 'student3', role: 'student' }
// ];

// const plainPassword = "123";
// const saltRounds = 10;

// async function generateSQL() {
//     for (const user of users) {
//         const hash = await bcrypt.hash(plainPassword, saltRounds);
//         console.log(`INSERT INTO users (username, password_hash, role) VALUES ('${user.username}', '${hash}', '${user.role}');`);
//     }
// }

// generateSQL();

app.listen(3000);
