import { Component, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  imports: [ReactiveFormsModule]
})
export class RegisterComponent {
  registerForm: FormGroup;
  private http = inject(HttpClient);
  private router = inject(Router); 

  constructor(private fb: FormBuilder) {
    this.registerForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      role: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.registerForm.valid) {
      const formData = this.registerForm.value;
      console.log('Form Submitted', formData);

      this.registerUser(formData).subscribe({
        next: response => console.log('Response from server:', response),
        error: error => console.error('Error during registration:', error)
      });
    }
  }

  registerUser(formData: any): Observable<any> {
    const apiUrl = 'http://localhost:3000/register';
    return this.http.post(apiUrl, formData); 
  }

  onAlreadyHasAccount() {
   this.router.navigate(['/login']);
  }
}
