import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-student-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './student-dashboard.component.html',
  styleUrls: ['./student-dashboard.component.css']
})

export class StudentDashboardComponent implements OnInit {
  exams: any[] = [];
  currentExam: any = null;
  currentQuestionIndex: number = 0;
  correctans:number=0;
  selectedAnswers: number[] = [];
  score: number | null = null;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.getExams();
  }

  
  getExams(): void {
    this.http.get<any[]>('http://localhost:3000/exams')
      .pipe(catchError(error => {
        console.error('Error fetching exams:', error);
        return of([]); 
      }))
      .subscribe((data) => {
        this.exams = data;
      });
  }

  
  attemptExam(examId: number): void {
    this.http.get<any>(`http://localhost:3000/exam/${examId}`)
      .pipe(catchError(error => {
        console.error('Error fetching exam details:', error);
        return of(null);  
      }))
      .subscribe((data) => {
        if (data) {
          this.currentExam = data;
          this.currentQuestionIndex = 0;
          this.selectedAnswers = new Array(this.currentExam.questions.length).fill(null); 
          this.score = null;
        }
      });
  }
  

 
  nextQuestion(): void {
    if (this.currentQuestionIndex < this.currentExam.questions.length - 1) {
      this.currentQuestionIndex++;
    }
  }

  prevQuestion(): void {
    if (this.currentQuestionIndex > 0) {
      this.currentQuestionIndex--;
    }
  }

  
  submitExam(): void {
    this.correctans = 0; 
  
    for (let i = 0; i < this.currentExam.questions.length; i++) {
      if (this.currentExam.questions[i].correct_option === this.selectedAnswers[i]) {
        this.correctans++;
      }
    }
  
    this.score = (this.correctans / this.currentExam.questions.length) * 100;
  
    this.http.post('http://localhost:3000/save-score', {
      exam_id: this.currentExam.exam_id,
      score: this.score
    }).subscribe(() => {
      alert('Exam submitted successfully!');
    });
  }}
  
