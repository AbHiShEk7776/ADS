import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { jwtDecode } from 'jwt-decode'; // Adjusted import for jwtDecode



@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private authUrl = 'http://localhost:5000/api/auth';
  private tokenKey = 'authToken';

  constructor(private http: HttpClient) { }

  login(credentials: any) { // Explicit type for credentials

    return this.http.post(`${this.authUrl}/login`, credentials).pipe(
      catchError(error => {
        console.error('Login failed', error);
        return throwError('Login failed; please try again later.');
      })
    );
  }


  register(userData: any) { // Explicit type for userData

    return this.http.post(`${this.authUrl}/register`, userData).pipe(
      catchError(error => {
        console.error('Registration failed', error);
        return throwError('Registration failed; please try again later.');
      })
    );
  }


  saveToken(token: string) {
    localStorage.setItem(this.tokenKey, token);
  }

  getToken() {
    return localStorage.getItem(this.tokenKey);
  }

  getUserRole() {
    const token = this.getToken();
    if (token) {
      const decoded: any = jwtDecode(token);

      return decoded.role;
    }
    return null;
  }

  isLoggedIn() {
    return !!this.getToken();
  }

  logout() {
    localStorage.removeItem(this.tokenKey);
  }
}
