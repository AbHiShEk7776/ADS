import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-teacher-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './teacher-dashboard.component.html',
  styleUrls: ['./teacher-dashboard.component.css']
})
export class TeacherDashboardComponent implements OnInit {
  exams: any[] = [];
  scores: any[] = [];
  examName: string = '';
  duration: number = 0;
  examIdForQuestions: number | null = null;
  questionText: string = '';
  options: string[] = ['', '', '', ''];
  correctOptions:boolean[] = [];

  private apiUrl = 'http://localhost:3000'; 

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.getExams();
  }

  
  getExams(): void {
    this.http.get<any[]>(`${this.apiUrl}/exams`)
      .pipe(catchError(error => {
        console.error('Error fetching exams:', error);
        return of([]);  
      }))
      .subscribe((data) => {
        this.exams = data;
      });
  }

  
  createExam(): void {
    if (this.examName && this.duration > 0) {
      const examData = {
        exam_name: this.examName,
        creator_id: 1, 
        duration: this.duration
      };

      this.http.post<any>(`${this.apiUrl}/create-exam`, examData)
        .pipe(catchError(error => {
          console.error('Error creating exam:', error);
          return of(null); 
        }))
        .subscribe((response) => {
          if (response) {
            this.examIdForQuestions = response.exam_id;
            alert('Exam created successfully');
          }
        });
    }
  }

  
  toggleCorrectOption(index: number, event: Event): void {
    const target = event.target as HTMLInputElement;
    this.correctOptions[index] = target.checked;
  }
  
  addQuestion(): void {
    if (this.questionText && this.options.every(opt => opt.trim() !== '')) {
      const questionData = {
        question_text: this.questionText,
        created_by: 1, 
        exam_id: this.examIdForQuestions,
        options: this.options.map((text, index) => ({
          option_text: text,
          is_correct: this.correctOptions[index] || false 
        }))
      };
  
      this.http.post(`${this.apiUrl}/add-question-to-exam`, questionData)
        .pipe(catchError(error => {
          console.error('Error adding question:', error);
          return of(null); 
        }))
        .subscribe(() => {
          alert('Question added successfully');
          this.resetQuestionForm();
        });
    }
  }
  
  resetQuestionForm(): void {
    this.questionText = '';
    this.options = ['', '', '', ''];
    this.correctOptions = [false, false, false, false]; 
  }
  
  
  

  
  viewScores(examId: number): void {
    this.http.get<any[]>(`${this.apiUrl}/student-exams/${examId}`)
      .pipe(catchError(error => {
        console.error('Error fetching scores:', error);
        return of([]);
      }))
      .subscribe((data) => {
        this.scores = data;
      });
  }


  
}
