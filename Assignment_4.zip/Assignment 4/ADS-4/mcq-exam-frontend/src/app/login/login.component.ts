import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';


@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  imports: [FormsModule, CommonModule]
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  async login() {
    try {
      const response = await firstValueFrom(
        this.http.post<any>('http://localhost:3000/api/auth/login', 

          {
            username: this.username,
            password: this.password
          }
        )
      );

      
      if (response.token) {
        localStorage.setItem('authToken', response.token);
      }

      
      if (response.role === 'student') {
        this.router.navigate(['/student-dashboard']);
      } else if (response.role === 'teacher') {
        this.router.navigate(['/teacher-dashboard']);
      }
    } catch (error) {
      if (error instanceof HttpErrorResponse) {
        switch (error.status) {
          case 401:
            this.errorMessage = 'Invalid username or password';
            break;
          case 404:
            this.errorMessage = 'Login endpoint not found';
            break;
          case 500:
            this.errorMessage = 'Server error, please try again later';
            break;
          default:
            this.errorMessage = 'An unexpected error occurred';
        }
      } else {
        this.errorMessage = 'Network error, please check your connection';
      }
    }
  }

  
}
